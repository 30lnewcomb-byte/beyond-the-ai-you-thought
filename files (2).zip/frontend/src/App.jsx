import React, {useState} from "react";
import axios from "axios";

export default function App(){
  const [text, setText] = useState("");
  const [resp, setResp] = useState(null);

  async function onChat(){
    const r = await axios.post("/api/chat", { user_id: "devuser", text });
    setResp(r.data);
  }

  return (
    <div style={{padding:20}}>
      <h2>Assistant Prototype</h2>
      <textarea rows={4} cols={80} value={text} onChange={e=>setText(e.target.value)} />
      <br/>
      <button onClick={onChat}>Ask</button>
      <pre>{JSON.stringify(resp, null, 2)}</pre>
    </div>
  );
}