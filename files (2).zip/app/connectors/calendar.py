# Calendar connector stub (Google Calendar placeholder)
class CalendarConnector:
    def __init__(self):
        pass

    def find_free_times(self, user_id, attendees, window):
        # Placeholder: return fixed candidate times
        return ["2026-04-07T15:00:00Z", "2026-04-08T16:00:00Z"]

    def create_event(self, user_id, event):
        # Placeholder: return fake event id
        return {"event_id": "evt_123", "status": "created"}