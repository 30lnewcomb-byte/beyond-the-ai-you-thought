# Email connector stub (SMTP/SendGrid placeholder)
class EmailConnector:
    def __init__(self):
        pass

    def send_email(self, to, subject, body):
        # Placeholder: pretend we sent an email
        return {"message_id": "msg_123", "status": "sent"}