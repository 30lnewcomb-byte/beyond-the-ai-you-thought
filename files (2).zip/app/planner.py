import uuid
from typing import Dict
from app.rag import Retriever

class Planner:
    def __init__(self, retriever: Retriever):
        self.retriever = retriever
        self.plans: Dict[str, Dict] = {}

    def create_plan(self, user_id: str, intent: str) -> Dict:
        # Step 1: fetch context
        context = self.retriever.retrieve(intent, k=5)
        # Step 2: call LLM (abstracted) to decompose into steps
        # For prototype, create a simple plan
        plan_id = str(uuid.uuid4())
        plan = {
            "id": plan_id,
            "user_id": user_id,
            "intent": intent,
            "steps": [
                {"type": "find_times", "description": "Find candidate times"},
                {"type": "draft_agenda", "description": "Generate agenda from notes"},
                {"type": "propose_times", "description": "Propose times to user"},
                {"type": "send_invites", "description": "Create calendar event and send invites"},
            ],
            "context": context,
            "status": "proposed",
        }
        self.plans[plan_id] = plan
        return plan

    def get_plan(self, plan_id: str):
        return self.plans.get(plan_id)