# Simple RAG retriever stub using in-memory embeddings
from typing import List

class Retriever:
    def __init__(self):
        # placeholder vector store: list of (id, text, embedding)
        self.docs = []

    def index(self, doc_id: str, text: str, embedding: List[float]):
        self.docs.append((doc_id, text, embedding))

    def retrieve(self, query: str, k: int = 3):
        # placeholder: return last k docs
        return [d[1] for d in self.docs[-k:]]