import uuid
from typing import Dict, Any

class ActionQueue:
    def __init__(self):
        self.queue: Dict[str, Any] = {}

    def enqueue(self, plan: Dict):
        action_id = str(uuid.uuid4())
        self.queue[action_id] = {"plan": plan, "status": "pending"}
        return action_id

    def approve(self, action_id: str):
        if action_id in self.queue:
            self.queue[action_id]["status"] = "approved"
            return True
        return False