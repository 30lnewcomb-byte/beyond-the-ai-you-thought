from fastapi import FastAPI, HTTPException, Body
from pydantic import BaseModel
from app.rag import Retriever
from app.planner import Planner
from app.connectors.calendar import CalendarConnector
from app.connectors.emailer import EmailConnector
from app.queue import ActionQueue

app = FastAPI(title="Assistant Prototype")

retriever = Retriever()
planner = Planner(retriever=retriever)
calendar = CalendarConnector()
emailer = EmailConnector()
queue = ActionQueue()

class ChatRequest(BaseModel):
    user_id: str
    text: str

class PlanRequest(BaseModel):
    user_id: str
    intent: str  # e.g., "schedule meeting with team next week"

@app.post("/chat")
async def chat(req: ChatRequest):
    # Simple RAG-based short answer
    context = retriever.retrieve(req.text, k=5)
    # For prototype, just return retrieved docs
    return {"answer": "I found context.", "context": context}

@app.post("/plan")
async def make_plan(req: PlanRequest):
    plan = planner.create_plan(req.user_id, req.intent)
    return {"plan": plan}

@app.post("/execute")
async def execute_plan(user_id: str = Body(...), plan_id: str = Body(...)):
    plan = planner.get_plan(plan_id)
    if not plan:
        raise HTTPException(status_code=404, detail="Plan not found")
    # enqueue for approval/exec
    action_id = queue.enqueue(plan)
    return {"action_id": action_id, "status": "queued"}