# assistant-prototype

A prototype AI assistant focused on calendar+email automation (FastAPI backend + simple React frontend). This scaffold includes:

- FastAPI backend with LLM + embeddings adapter (OpenAI default)
- RAG/memory stubs (FAISS dev fallback)
- Planner/agent skeleton
- Google Calendar OAuth wiring & SMTP/SendGrid email adapter stubs
- Local Docker Compose for dev, Helm chart scaffold for k8s
- GitHub Actions CI (lint, unit-tests, build)
- create_repo.sh script to create/push the repo to GitHub

Repository owner: 30lnewcomb-byte  
Repository name: assistant-prototype (public)

Quickstart (local)
1. Install prerequisites:
   - git, docker, docker-compose
   - Python 3.11
   - Node 18+
   - GitHub CLI (gh) and authenticate (`gh auth login`)

2. Create the repo on GitHub and push:
   ./scripts/create_repo.sh

3. Create local .env from .env.example and fill secrets:
   cp .env.example .env
   (edit .env to add OPENAI_API_KEY, GOOGLE_CLIENT_ID & GOOGLE_CLIENT_SECRET, SMTP_* etc.)

4. Start locally:
   docker-compose up --build

5. Open UI:
   http://localhost:3000 (React)
   API: http://localhost:8080

Core endpoints (prototype)
- POST /api/chat      -> { user_id, text } — RAG + short answer (returns context and candidate answers)
- POST /api/plan      -> { user_id, intent } — produce a proposed plan (decomposed steps)
- POST /api/execute   -> { user_id, plan_id } — enqueue plan for approval/execution
- POST /api/queue/{action_id}/approve -> approve queued action (executes calendar/email stubs)

Security and secrets
- Do NOT commit real credentials. Use GitHub Secrets for CI and the repo. See .env.example.

Notes
- The connectors are stubs for safety. Replace with full production-grade implementations before any real use.
- For production: wire a managed vector DB (Weaviate/Milvus), persistent Postgres, and host models responsibly.

If you want, run `./scripts/create_repo.sh` now and I’ll provide the link pattern to your new repo and the exact commands to add secrets and run CI.