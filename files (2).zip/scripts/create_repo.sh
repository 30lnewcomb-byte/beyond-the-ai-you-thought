#!/usr/bin/env bash
set -e

REPO_OWNER="30lnewcomb-byte"
REPO_NAME="assistant-prototype"
VISIBILITY="public" # public or private

if ! command -v gh >/dev/null; then
  echo "gh CLI not found. Install from https://cli.github.com/"
  exit 1
fi

# create remote repo
echo "Creating GitHub repo ${REPO_OWNER}/${REPO_NAME} (${VISIBILITY})..."
gh repo create "${REPO_OWNER}/${REPO_NAME}" --${VISIBILITY} --source=. --remote=origin --push

echo "Repo created and initial commit pushed."
echo "Next: go to https://github.com/${REPO_OWNER}/${REPO_NAME} and add repository secrets as described in README."