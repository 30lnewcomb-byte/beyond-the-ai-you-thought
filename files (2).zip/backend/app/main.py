from fastapi import FastAPI, HTTPException, Body
from pydantic import BaseModel
from .rag import Retriever
from .planner import Planner
from .connectors.calendar import CalendarConnector
from .connectors.emailer import EmailConnector
from .queue import ActionQueue
from .db import init_db
from .oauth_google import router as oauth_router

app = FastAPI(title="Assistant Prototype API", version="0.2.0")

# init DB (create tables) at startup for prototype
@app.on_event("startup")
def on_startup():
    init_db()

# subcomponents
retriever = Retriever()
planner = Planner(retriever=retriever)
calendar = CalendarConnector()
emailer = EmailConnector()
queue = ActionQueue()

class ChatRequest(BaseModel):
    user_id: str
    text: str

class PlanRequest(BaseModel):
    user_id: str
    intent: str

app.include_router(oauth_router)

@app.post("/api/chat")
async def chat(req: ChatRequest):
    context = retriever.retrieve(req.text, k=5)
    return {"answer": "Here is context I found.", "context": context}

@app.post("/api/plan")
async def make_plan(req: PlanRequest):
    plan = planner.create_plan(req.user_id, req.intent)
    return {"plan": plan}

@app.post("/api/execute")
async def execute_plan(payload: dict = Body(...)):
    user_id = payload.get("user_id")
    plan_id = payload.get("plan_id")
    plan = planner.get_plan(plan_id)
    if not plan:
        raise HTTPException(status_code=404, detail="Plan not found")
    action_id = queue.enqueue(plan)
    return {"action_id": action_id, "status": "queued"}

@app.post("/api/queue/{action_id}/approve")
async def approve_action(action_id: str):
    ok = queue.approve(action_id)
    if not ok:
        raise HTTPException(status_code=404, detail="Action not found")
    action = queue.queue[action_id]
    plan = action["plan"]
    # Execute plan steps (prototype): find times, create event, send invites
    candidates = calendar.find_free_times(plan["user_id"], attendees=[], window="next_week")
    # Simplified: set start and end
    start = candidates[0]
    # add 1 hour duration
    from datetime import datetime, timedelta, timezone
    s = datetime.fromisoformat(start.replace("Z", "+00:00"))
    e = (s + timedelta(hours=1)).isoformat()
    event = {
        "summary": plan["intent"],
        "start": s.isoformat(),
        "end": e,
        "attendees": []
    }
    ev = calendar.create_event(plan["user_id"], event)
    email_resp = emailer.send_email(to="user@example.com", subject="Meeting scheduled", body=f"Event: {ev}")
    action["status"] = "executed"
    action["result"] = {"event": ev, "email": email_resp}
    return {"status": "executed", "result": action["result"]}