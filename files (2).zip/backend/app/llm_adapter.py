import os
import openai
from tenacity import retry, wait_exponential, stop_after_attempt, retry_if_exception_type

OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")
OPENAI_DEFAULT_MODEL = os.getenv("OPENAI_MODEL", "gpt-4o-mini")

if OPENAI_API_KEY:
    openai.api_key = OPENAI_API_KEY

@retry(wait=wait_exponential(min=1, max=10), stop=stop_after_attempt(3), retry=retry_if_exception_type(Exception))
def call_completion(prompt: str, model: str = None, max_tokens: int = 512, temperature: float = 0.2):
    """
    Simple wrapper around OpenAI ChatCompletion with retries.
    """
    if not OPENAI_API_KEY:
        raise RuntimeError("OPENAI_API_KEY not set")
    model = model or OPENAI_DEFAULT_MODEL
    resp = openai.ChatCompletion.create(
        model=model,
        messages=[{"role":"user","content":prompt}],
        max_tokens=max_tokens,
        temperature=temperature,
    )
    return resp.choices[0].message.content