import os
from datetime import datetime, timedelta, timezone
from google.oauth2.credentials import Credentials
from googleapiclient.discovery import build
from google.auth.transport.requests import Request as GoogleRequest
from .db import SessionLocal
from .models import OAuthToken
import json

class CalendarConnector:
    def __init__(self):
        self.default_calendar = "primary"

    def _get_token_row(self, db, user_id: str):
        return db.query(OAuthToken).filter_by(user_id=user_id, provider="google").first()

    def _get_google_credentials(self, user_id: str):
        db = SessionLocal()
        try:
            token_row = self._get_token_row(db, user_id)
            if not token_row:
                return None, None
            creds = Credentials(
                token=token_row.access_token,
                refresh_token=token_row.refresh_token,
                token_uri=token_row.token_uri,
                client_id=token_row.client_id,
                client_secret=token_row.client_secret,
                scopes=json.loads(token_row.scopes) if token_row.scopes else None,
            )
            return creds, token_row
        finally:
            db.close()

    def _maybe_refresh_and_persist(self, creds: Credentials, token_row: OAuthToken):
        """
        If credentials are expired or close to expiry, refresh and persist new access token + expiry.
        """
        if not creds or not token_row:
            return creds

        # If no refresh_token is available, we can't refresh.
        if not creds.refresh_token:
            return creds

        # If not expired and expiry is more than 2 minutes away, no op
        now = datetime.now(timezone.utc)
        if creds.expiry and (creds.expiry - now) > timedelta(seconds=120):
            return creds

        # refresh
        try:
            request = GoogleRequest()
            creds.refresh(request)
            # persist refreshed token back to DB
            db = SessionLocal()
            try:
                row = db.query(OAuthToken).filter_by(id=token_row.id).first()
                if row:
                    row.access_token = creds.token
                    # refresh_token might be None on refresh; preserve if present
                    if creds.refresh_token:
                        row.refresh_token = creds.refresh_token
                    row.expiry = creds.expiry.replace(tzinfo=timezone.utc) if creds.expiry else None
                    db.add(row)
                    db.commit()
            finally:
                db.close()
        except Exception as e:
            # Do not crash entire flow — log and return unrefreshed creds
            # In production, use structured logging instead of print
            print("Warning: failed to refresh Google credentials:", str(e))
        return creds

    def find_free_times(self, user_id, attendees, window="next_week"):
        creds, token_row = self._get_google_credentials(user_id)
        creds = self._maybe_refresh_and_persist(creds, token_row)

        if not creds:
            # fallback fixed times
            return ["2026-04-07T15:00:00Z", "2026-04-08T16:00:00Z"]

        service = build("calendar", "v3", credentials=creds, cache_discovery=False)

        now = datetime.now(timezone.utc)
        time_min = now.isoformat()
        time_max = (now + timedelta(days=7)).isoformat()

        body = {
            "timeMin": time_min,
            "timeMax": time_max,
            "items": [{"id": self.default_calendar}],
        }
        fb = service.freebusy().query(body=body).execute()
        busy = fb.get("calendars", {}).get(self.default_calendar, {}).get("busy", [])

        candidates = []
        for d in range(1, 8):
            if len(candidates) >= 2:
                break
            day = (now + timedelta(days=d)).replace(hour=15, minute=0, second=0, microsecond=0)
            day_iso = day.isoformat()
            overlap = False
            for b in busy:
                b_start = datetime.fromisoformat(b["start"].replace("Z", "+00:00"))
                b_end = datetime.fromisoformat(b["end"].replace("Z", "+00:00"))
                if b_start <= day <= b_end:
                    overlap = True
                    break
            if not overlap:
                candidates.append(day_iso)
        if not candidates:
            candidates = [ (now + timedelta(days=2)).replace(hour=15, minute=0).isoformat() ]
        return candidates

    def create_event(self, user_id, event: dict):
        creds, token_row = self._get_google_credentials(user_id)
        creds = self._maybe_refresh_and_persist(creds, token_row)

        if not creds:
            return {"error": "no_google_credentials", "status": "skipped", "details": event}

        service = build("calendar", "v3", credentials=creds, cache_discovery=False)

        g_event = {
            "summary": event.get("summary"),
            "description": event.get("description", ""),
            "start": {"dateTime": event.get("start"), "timeZone": "UTC"},
            "end": {"dateTime": event.get("end"), "timeZone": "UTC"},
            "attendees": [{"email": a} for a in event.get("attendees", [])],
            "reminders": {"useDefault": True},
        }
        created = service.events().insert(calendarId=self.default_calendar, body=g_event, sendUpdates="all").execute()
        return {"event_id": created.get("id"), "status": "created", "details": created}