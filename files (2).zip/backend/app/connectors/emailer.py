import os
from .emailer_sendgrid import SendGridEmailer
from .emailer_smtp import SMTPEmailer

class EmailConnector:
    def __init__(self):
        # prefer SendGrid if configured
        if os.getenv("SENDGRID_API_KEY"):
            self.impl = SendGridEmailer()
        else:
            # fall back to SMTP adapter (if configured) or simple stub
            self.impl = SMTPEmailer()

    def send_email(self, to, subject, body, cc=None, bcc=None):
        # normalize recipients: allow string or list
        if isinstance(to, str):
            recipients = [to]
        else:
            recipients = to or []
        return self.impl.send_email(recipients, subject, body, cc=cc, bcc=bcc)