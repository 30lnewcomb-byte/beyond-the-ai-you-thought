import os
from sendgrid import SendGridAPIClient
from sendgrid.helpers.mail import Mail, To, From, Personalization

class SendGridEmailer:
    def __init__(self):
        self.api_key = os.getenv("SENDGRID_API_KEY")
        if not self.api_key:
            raise RuntimeError("SENDGRID_API_KEY not set for SendGridEmailer")
        self.client = SendGridAPIClient(self.api_key)
        self.from_email = os.getenv("EMAIL_FROM", "no-reply@example.com")

    def send_email(self, to_list, subject, body, cc=None, bcc=None):
        """
        to_list: list[str]
        body: plain text or HTML (we send as html_content)
        """
        message = Mail(
            from_email=From(self.from_email),
            to_emails=[To(addr) for addr in to_list],
            subject=subject,
            html_content=body,
        )
        # optionally add cc/bcc
        if cc:
            for c in (cc if isinstance(cc, list) else [cc]):
                message.add_cc(c)
        if bcc:
            for b in (bcc if isinstance(bcc, list) else [bcc]):
                message.add_bcc(b)
        try:
            resp = self.client.send(message)
            return {"status": resp.status_code, "body": resp.body.decode() if hasattr(resp.body, "decode") else resp.body}
        except Exception as e:
            # in prototype, print and return error
            print("SendGrid send failed:", str(e))
            return {"status": "error", "error": str(e)}