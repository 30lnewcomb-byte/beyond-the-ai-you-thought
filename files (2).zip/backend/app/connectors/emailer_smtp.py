import os
import smtplib
from email.message import EmailMessage

class SMTPEmailer:
    def __init__(self):
        self.smtp_host = os.getenv("SMTP_HOST", "")
        self.smtp_port = int(os.getenv("SMTP_PORT", "587") or 587)
        self.smtp_user = os.getenv("SMTP_USER", "")
        self.smtp_password = os.getenv("SMTP_PASSWORD", "")
        self.from_email = os.getenv("EMAIL_FROM", "no-reply@example.com")

    def send_email(self, to_list, subject, body, cc=None, bcc=None):
        msg = EmailMessage()
        msg["Subject"] = subject
        msg["From"] = self.from_email
        msg["To"] = ", ".join(to_list)
        if cc:
            msg["Cc"] = ", ".join(cc if isinstance(cc, list) else [cc])
        if bcc:
            msg["Bcc"] = ", ".join(bcc if isinstance(bcc, list) else [bcc])
        msg.set_content(body, subtype="html")

        if not self.smtp_host:
            # fallback stub behavior: return pretend message
            print("SMTP not configured, stub send:", subject, "to", to_list)
            return {"status": "stub", "to": to_list}

        try:
            server = smtplib.SMTP(self.smtp_host, self.smtp_port, timeout=10)
            server.starttls()
            if self.smtp_user and self.smtp_password:
                server.login(self.smtp_user, self.smtp_password)
            server.send_message(msg)
            server.quit()
            return {"status": "sent", "to": to_list}
        except Exception as e:
            print("SMTP send failed:", str(e))
            return {"status": "error", "error": str(e)}