# Embeddings adapter (OpenAI embeddings or local fallback)
import os
import openai

OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")
if OPENAI_API_KEY:
    openai.api_key = OPENAI_API_KEY

def embed_text(text: str):
    if not OPENAI_API_KEY:
        # fallback: simple hash-based vector (not useful for production)
        return [float(sum(ord(c) for c in text) % 1000)]
    resp = openai.Embedding.create(model="text-embedding-3-large", input=text)
    return resp.data[0].embedding