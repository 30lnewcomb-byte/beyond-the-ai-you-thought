import os
import json
from fastapi import APIRouter, Request, HTTPException
from starlette.responses import RedirectResponse
from google_auth_oauthlib.flow import Flow
from google.oauth2.credentials import Credentials
from .db import SessionLocal
from .models import OAuthToken
from datetime import datetime, timezone

router = APIRouter(prefix="/api/oauth/google", tags=["oauth"])

GOOGLE_CLIENT_ID = os.getenv("GOOGLE_CLIENT_ID")
GOOGLE_CLIENT_SECRET = os.getenv("GOOGLE_CLIENT_SECRET")
# This should match the redirect you register in Google Cloud Console
GOOGLE_REDIRECT_URI = os.getenv("GOOGLE_REDIRECT_URI", "http://localhost:8080/api/oauth/google/callback")

SCOPES = [
    "https://www.googleapis.com/auth/calendar.events",
    "https://www.googleapis.com/auth/calendar.readonly",
    # add more scopes as needed
]

def build_flow(state: str = None):
    if not GOOGLE_CLIENT_ID or not GOOGLE_CLIENT_SECRET:
        raise RuntimeError("Google OAuth credentials not set")
    client_config = {
        "web": {
            "client_id": GOOGLE_CLIENT_ID,
            "client_secret": GOOGLE_CLIENT_SECRET,
            "auth_uri": "https://accounts.google.com/o/oauth2/auth",
            "token_uri": "https://oauth2.googleapis.com/token",
            "redirect_uris": [GOOGLE_REDIRECT_URI],
        }
    }
    flow = Flow.from_client_config(
        client_config=client_config,
        scopes=SCOPES,
        redirect_uri=GOOGLE_REDIRECT_URI,
        state=state,
    )
    return flow

@router.get("/start")
async def oauth_start(request: Request, user_id: str):
    """
    Start the OAuth 2.0 flow. Redirects user to Google consent screen.
    Provide user_id to associate tokens in the DB (prototype: pass as query).
    """
    flow = build_flow()
    authorization_url, state = flow.authorization_url(access_type="offline", include_granted_scopes="true", prompt="consent")
    # Store state mapping if needed; for prototype we pass user_id in state or query param
    # We'll append user_id as state (simple prototype)
    return RedirectResponse(authorization_url + f"&state={user_id}")

@router.get("/callback")
async def oauth_callback(request: Request):
    """
    Google will redirect here with code & state (we use state for user_id mapping).
    Exchange code for credentials and persist tokens.
    """
    request_query = dict(request.query_params)
    error = request_query.get("error")
    if error:
        raise HTTPException(status_code=400, detail=f"OAuth error: {error}")

    state = request_query.get("state")
    user_id = state or "default_user"

    flow = build_flow(state=state)
    # The flow expects the full request URL:
    full_url = str(request.url)
    flow.fetch_token(authorization_response=full_url)

    credentials = flow.credentials  # google.oauth2.credentials.Credentials
    # persist tokens to DB
    db = SessionLocal()
    try:
        # Upsert for this provider+user
        token = db.query(OAuthToken).filter_by(user_id=user_id, provider="google").first()
        if not token:
            token = OAuthToken(user_id=user_id, provider="google")
        token.access_token = credentials.token
        token.refresh_token = credentials.refresh_token
        token.token_uri = credentials.token_uri
        token.client_id = GOOGLE_CLIENT_ID
        token.client_secret = GOOGLE_CLIENT_SECRET
        token.scopes = json.dumps(credentials.scopes or SCOPES)
        token.expiry = credentials.expiry.replace(tzinfo=timezone.utc) if credentials.expiry else None
        db.add(token)
        db.commit()
    finally:
        db.close()

    # Redirect back to frontend UX (or a success page)
    return RedirectResponse(url="/?oauth=success")