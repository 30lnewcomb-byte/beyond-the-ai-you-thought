import uuid
from typing import Dict
from .rag import Retriever

class Planner:
    def __init__(self, retriever: Retriever):
        self.retriever = retriever
        self.plans: Dict[str, Dict] = {}

    def create_plan(self, user_id: str, intent: str) -> Dict:
        context = self.retriever.retrieve(intent, k=5)
        plan_id = str(uuid.uuid4())
        plan = {
            "id": plan_id,
            "user_id": user_id,
            "intent": intent,
            "steps": [
                {"id": "s1", "type": "find_times", "description": "Find candidate times"},
                {"id": "s2", "type": "draft_agenda", "description": "Generate agenda from notes"},
                {"id": "s3", "type": "propose_times", "description": "Propose times to user"},
                {"id": "s4", "type": "send_invites", "description": "Create calendar event and send invites"},
            ],
            "context": context,
            "status": "proposed",
        }
        self.plans[plan_id] = plan
        return plan

    def get_plan(self, plan_id: str):
        return self.plans.get(plan_id)