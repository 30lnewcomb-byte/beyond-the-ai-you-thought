# Simple in-memory RAG retriever stub using a list (dev)
from typing import List, Tuple

class Retriever:
    def __init__(self):
        # docs: list of (id, text)
        self.docs: List[Tuple[str, str]] = []
        # seed with sample docs
        self.docs.append(("d1", "Project notes: Q2 planning, discuss roadmap and milestones."))
        self.docs.append(("d2", "Design doc: meeting agenda template includes goals, attendees, and action items."))
        self.docs.append(("d3", "Previous meeting notes: decisions on hiring and timelines."))

    def index(self, doc_id: str, text: str):
        self.docs.append((doc_id, text))

    def retrieve(self, query: str, k: int = 3):
        # Prototype: return top-k docs (last k)
        return [d[1] for d in self.docs[-k:]]