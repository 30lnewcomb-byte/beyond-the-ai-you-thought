from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, declarative_base
import os

DATABASE_URL = os.getenv("DATABASE_URL", "postgresql://postgres:password@db:5432/assistant")

# Using SQLAlchemy sync engine for prototype simplicity
engine = create_engine(DATABASE_URL, future=True, echo=False)
SessionLocal = sessionmaker(bind=engine, autoflush=False, autocommit=False)
Base = declarative_base()

def init_db():
    # import models to ensure they are registered on Base
    from . import models  # noqa: F401
    Base.metadata.create_all(bind=engine)