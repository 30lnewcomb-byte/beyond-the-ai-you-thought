# Basic unit test placeholder for planner
def test_create_plan():
    from app.rag import Retriever
    from app.planner import Planner
    r = Retriever()
    p = Planner(retriever=r)
    plan = p.create_plan("u1", "schedule team sync next week")
    assert plan["user_id"] == "u1"
    assert "steps" in plan